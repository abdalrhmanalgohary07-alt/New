package com.example.floatlauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat

/** حاوية ثابتة (مش بتتحول) بتلتقط القرص بإصبعين عشان تكبّر/تصغّر اللوحة. */
class PinchLayout(ctx: Context, private val scaleBy: (Float) -> Unit) : FrameLayout(ctx) {
    private val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { scaleBy(d.scaleFactor); return true }
    })
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        return sd.isInProgress || e.pointerCount > 1
    }
    override fun onTouchEvent(e: MotionEvent): Boolean { sd.onTouchEvent(e); return true }
}

/** لانشر: شاشة كبيرة واحدة ثابتة على الشاشة (بتتحرك معاك). اسحب الشريط العلوي للتحريك، واقرص بإصبعين للتكبير. */
class LauncherActivity : ComponentActivity() {
    private lateinit var root: PinchLayout
    private lateinit var preview: PreviewView
    private lateinit var panel: LinearLayout
    private lateinit var grid: GridLayout
    private lateinit var scroll: ScrollView
    private lateinit var lockBtn: TextView
    private val prefs by lazy { getSharedPreferences("ui", MODE_PRIVATE) }

    private var px = 0f; private var py = 0f; private var scale = 1f
    private var locked = false; private var camOn = false; private var appCount = -1
    private var lastX = 0f; private var lastY = 0f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun applyPanel() {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        px = px.coerceIn(-w, w); py = py.coerceIn(-h, h)
        panel.translationX = px; panel.translationY = py
        panel.scaleX = scale; panel.scaleY = scale
    }

    private fun save() {
        prefs.edit().putFloat("x", px).putFloat("y", py).putFloat("s", scale)
            .putBoolean("lock", locked).putBoolean("cam", camOn).apply()
    }

    private fun hbtn(t: String, f: (TextView) -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; setTextColor(Color.WHITE)
        setPadding(dp(10), dp(6), dp(10), dp(6))
        setOnClickListener { f(this) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        px = prefs.getFloat("x", 0f); py = prefs.getFloat("y", 0f); scale = prefs.getFloat("s", 1f)
        locked = prefs.getBoolean("lock", false)

        root = PinchLayout(this) { f ->
            if (!locked) { scale = (scale * f).coerceIn(0.4f, 3f); applyPanel() }
        }
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF1B2A55.toInt(), 0xFF05070F.toInt())
        )
        preview = PreviewView(this).apply { visibility = View.GONE }
        root.addView(preview, ViewGroup.LayoutParams(-1, -1))

        // الشاشة الكبيرة
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        val panelW = minOf(dp(532), (sw * 0.95f).toInt())
        val panelH = (sh * 0.7f).toInt()
        val cols = maxOf(3, panelW / dp(100))

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xD9101626.toInt()); cornerRadius = dp(24).toFloat(); setStroke(dp(2), 0x66FFFFFF)
            }
            clipToOutline = true
        }

        // الشريط العلوي: اسحبه لتحريك الشاشة
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x40FFFFFF)
            setPadding(dp(12), 0, dp(4), 0)
        }
        header.addView(TextView(this).apply { text = "☰ اسحب من هنا"; setTextColor(Color.WHITE); textSize = 14f },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(hbtn("➖") { if (!locked) { scale = (scale * 0.9f).coerceIn(0.4f, 3f); applyPanel(); save() } })
        header.addView(hbtn("➕") { if (!locked) { scale = (scale * 1.1f).coerceIn(0.4f, 3f); applyPanel(); save() } })
        header.addView(hbtn("📷") { setCamera(!camOn) })
        lockBtn = hbtn(if (locked) "🔒" else "🔓") {
            locked = !locked; it.text = if (locked) "🔒" else "🔓"; save()
        }
        header.addView(lockBtn)
        header.addView(hbtn("⌖") { px = 0f; py = 0f; scale = 1f; applyPanel(); save() })
        header.setOnTouchListener { _, e ->
            if (locked) return@setOnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lastX = e.rawX; lastY = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    px += e.rawX - lastX; py += e.rawY - lastY
                    lastX = e.rawX; lastY = e.rawY; applyPanel()
                }
                MotionEvent.ACTION_UP -> save()
            }
            true
        }
        panel.addView(header, LinearLayout.LayoutParams(-1, dp(48)))

        grid = GridLayout(this).apply { columnCount = cols; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        scroll = ScrollView(this).apply { addView(grid) }
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(panel, FrameLayout.LayoutParams(panelW, panelH, Gravity.CENTER))
        setContentView(root)
        applyPanel()
        loadApps()
        if (prefs.getBoolean("cam", false)) setCamera(true)
    }

    private fun loadApps() {
        val pm = packageManager
        val list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).sortedBy { it.loadLabel(pm).toString().lowercase() }
        if (list.size == appCount) return
        appCount = list.size
        grid.removeAllViews()
        for (ri in list) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(6), 0, dp(6))
                addView(ImageView(this@LauncherActivity).apply { setImageDrawable(ri.loadIcon(pm)) },
                    LinearLayout.LayoutParams(dp(56), dp(56)))
                addView(TextView(this@LauncherActivity).apply {
                    text = ri.loadLabel(pm); textSize = 11f; setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER; maxLines = 1
                }, LinearLayout.LayoutParams(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT))
                setOnClickListener {
                    pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
                        ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { startActivity(it) }
                }
            }
            val lp = GridLayout.LayoutParams().apply { width = dp(100); height = ViewGroup.LayoutParams.WRAP_CONTENT }
            grid.addView(cell, lp)
        }
    }

    private fun setCamera(on: Boolean) {
        if (on && checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.CAMERA), 2); return
        }
        camOn = on
        save()
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get(); p.unbindAll()
            if (on) {
                val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv)
                preview.visibility = View.VISIBLE
            } else preview.visibility = View.GONE
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 2 && res.firstOrNull() == PackageManager.PERMISSION_GRANTED) setCamera(true)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); scroll.scrollTo(0, 0) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* اللانشر ما بيقفلش */ }

    override fun onResume() { super.onResume(); loadApps() }
    override fun onPause() { super.onPause(); save() }
}
