package com.example.floatlauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot

/** يلتقط السحب بإصبع بدون ما يمنع الضغط على الأيقونات. */
class DragLayout(ctx: Context, private val onDrag: (Float, Float) -> Unit) : FrameLayout(ctx) {
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var sx = 0f; private var sy = 0f; private var lx = 0f; private var ly = 0f
    private var dragging = false

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; lx = e.x; ly = e.y; dragging = false }
            MotionEvent.ACTION_MOVE -> if (!dragging && hypot(e.x - sx, e.y - sy) > slop) {
                dragging = true; lx = e.x; ly = e.y
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
            MotionEvent.ACTION_MOVE -> { onDrag(e.x - lx, e.y - ly); lx = e.x; ly = e.y }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}

/** لانشر: تطبيقاتك معلّقة حواليك في فضاء 3D. لف بالجهاز أو اسحب بإصبعك، واضغط على الأيقونة لفتحها. */
class LauncherActivity : ComponentActivity(), SensorEventListener {
    // لو اتجاه الحركة معكوس على جهازك، غيّر الإشارة من 1f إلى -1f
    private val SIGN_YAW = 1f
    private val SIGN_PITCH = 1f

    private class Cell(val view: View, val az: Float, val el: Float)
    private val cells = ArrayList<Cell>()
    private lateinit var root: DragLayout
    private lateinit var preview: PreviewView
    private var camOn = false
    private var appCount = -1

    private var yaw = 0f; private var pitch = 0f
    private var yaw0: Float? = null; private var pitch0 = 0f
    private var yawOff = 0f; private var lookOff = 0f
    private val rot = FloatArray(9); private val rot2 = FloatArray(9); private val ori = FloatArray(3)
    private val twoPi = (2 * Math.PI).toFloat()
    private val pxPerRad: Float get() = resources.displayMetrics.widthPixels * 0.885f  // مجال رؤية تقريبي 65 درجة

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun wrap(a: Float): Float {
        var x = a
        while (x > Math.PI) x -= twoPi
        while (x < -Math.PI) x += twoPi
        return x
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = DragLayout(this) { dx, dy ->
            yawOff -= dx / pxPerRad     // المحتوى يتحرك مع الإصبع
            lookOff += dy / pxPerRad
            update()
        }
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF1B2A55.toInt(), 0xFF05070F.toInt())
        )
        preview = PreviewView(this).apply { visibility = View.GONE }
        root.addView(preview, ViewGroup.LayoutParams(-1, -1))

        val bar = LinearLayout(this)
        bar.addView(Button(this).apply { text = "⌖"; setOnClickListener { recenter() } })
        bar.addView(Button(this).apply { text = "📷"; setOnClickListener { setCamera(!camOn) } })
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { topMargin = dp(36); marginEnd = dp(8) })

        setContentView(root)
        loadApps()
    }

    private fun loadApps() {
        val pm = packageManager
        val list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).sortedBy { it.loadLabel(pm).toString().lowercase() }
        if (list.size == appCount) return
        appCount = list.size
        for (c in cells) root.removeView(c.view)
        cells.clear()

        val cols = 15
        val stepAz = (360f / cols) * (Math.PI / 180).toFloat()
        val stepEl = 22f * (Math.PI / 180).toFloat()
        val rows = (list.size + cols - 1) / cols
        list.forEachIndexed { i, ri ->
            val col = i % cols; val row = i / cols
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                cameraDistance = 8000f * resources.displayMetrics.density
                addView(ImageView(this@LauncherActivity).apply { setImageDrawable(ri.loadIcon(pm)) },
                    LinearLayout.LayoutParams(dp(64), dp(64)))
                addView(TextView(this@LauncherActivity).apply {
                    text = ri.loadLabel(pm); textSize = 11f; setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER; maxLines = 1; setShadowLayer(4f, 0f, 0f, Color.BLACK)
                }, LinearLayout.LayoutParams(dp(96), -2))
                setOnClickListener {
                    pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
                        ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { startActivity(it) }
                }
            }
            root.addView(cell, FrameLayout.LayoutParams(dp(96), -2, Gravity.CENTER))
            cells.add(Cell(cell, (col - 3) * stepAz, ((rows - 1) / 2f - row) * stepEl))
        }
        update()
    }

    private fun recenter() { yaw0 = yaw; pitch0 = pitch; yawOff = 0f; lookOff = 0f; update() }

    private fun update() {
        val y0 = yaw0 ?: return
        val yawTotal = SIGN_YAW * wrap(yaw - y0) + yawOff
        val look = SIGN_PITCH * (pitch - pitch0) + lookOff
        for (c in cells) {
            val dth = wrap(c.az - yawTotal)
            val dph = c.el - look
            val v = c.view
            if (abs(dth) > 1.05f || abs(dph) > 0.9f) { v.visibility = View.INVISIBLE; continue }
            v.visibility = View.VISIBLE
            val k = 0.55f + 0.45f * cos(dth) * cos(dph)
            v.translationX = pxPerRad * dth
            v.translationY = -pxPerRad * dph
            v.scaleX = k; v.scaleY = k
            v.alpha = (1.2f - hypot(dth, dph)).coerceIn(0.25f, 1f)
            v.rotationY = (-Math.toDegrees(dth.toDouble()) * 0.6).toFloat()
        }
    }

    private fun setCamera(on: Boolean) {
        if (on && checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.CAMERA), 2); return
        }
        camOn = on
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get(); p.unbindAll()
            if (on) {
                val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv)
                preview.visibility = View.VISIBLE
            } else preview.visibility = View.GONE
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 2 && res.firstOrNull() == PackageManager.PERMISSION_GRANTED) setCamera(true)
    }

    override fun onSensorChanged(e: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rot, e.values)
        @Suppress("DEPRECATION")
        val r = windowManager.defaultDisplay.rotation
        val (ax, ay) = when (r) {
            android.view.Surface.ROTATION_90 -> SensorManager.AXIS_Z to SensorManager.AXIS_MINUS_X
            android.view.Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Z
            android.view.Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Z to SensorManager.AXIS_X
            else -> SensorManager.AXIS_X to SensorManager.AXIS_Z
        }
        SensorManager.remapCoordinateSystem(rot, ax, ay, rot2)
        SensorManager.getOrientation(rot2, ori)
        yaw = ori[0]; pitch = ori[1]
        if (yaw0 == null) { yaw0 = yaw; pitch0 = pitch }
        update()
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); recenter() }   // ضغطة Home ترجّعك للنص

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* اللانشر ما بيقفلش */ }

    override fun onResume() {
        super.onResume()
        loadApps()
        val sm = getSystemService(SensorManager::class.java)
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR), SensorManager.SENSOR_DELAY_GAME)
    }
    override fun onPause() { super.onPause(); getSystemService(SensorManager::class.java).unregisterListener(this) }
}
